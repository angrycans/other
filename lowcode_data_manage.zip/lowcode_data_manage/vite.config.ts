import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

const WORK_ENV = "http://work.digital.com";
const DEV_ENV = "http://dev-online.cs-os.com";

const CURRENT_ENV = WORK_ENV;

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [react()],
  build: {
    sourcemap: true,
  },
  server: {
    host: "0.0.0.0",
    port: 3333,
    cors: true,
    proxy: {
      "/digitalos-admin": {
        target: `${CURRENT_ENV}/digitalos-admin`,
        changeOrigin: true,
        rewrite: (path) => path.replace(/^\/digitalos-admin/, ""),
      },
      "/wind_tiger": {
        target: "http://192.168.2.73:8000/wind_tiger",
        changeOrigin: true,
        rewrite: (path) => path.replace(/^\/wind_tiger/, ""),
      },
      "/digital-dip": {
        target: `${CURRENT_ENV}/digital-dip/`,
        changeOrigin: true,
        rewrite: (path) => path.replace(/^\/digital-dip/, "/digital-dip"),
      },
      "/digital": {
        target: `${CURRENT_ENV}/lowcode_flow/`,
        changeOrigin: true,
      },
    },
  },
});
