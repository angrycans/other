import React, { useEffect } from "react";
import {
  AppstoreOutlined,
  BarChartOutlined,
  CloudOutlined,
  ShopOutlined,
  TeamOutlined,
  UploadOutlined,
  UserOutlined,
  VideoCameraOutlined,
} from "@ant-design/icons";
import type { MenuProps } from "antd";
import { Routes, Route, Outlet, Link, useLocation } from "react-router-dom";
import { Breadcrumb } from "antd";
import { useParams } from "react-router-dom";

import DashBoard from "./views/dashbord";
import AppConfig from "./AppConfig";
const About = React.lazy(() => import("./views/home"));
const DataManage = React.lazy(() => import("./views/data-manage"));

// 定义路由的面包屑名称映射（可根据需要自行扩展）
export const breadcrumbNameMap: { [key: string]: string } = {
  "/": "Home",
  "/data-manage": "数据管理",

  // 这里可以添加更多的路径和对应的面包屑名称
};

const App: React.FC = () => {
  return (
    <Routes>
      <Route path="/" element={<DashBoard />}>
        <Route
          index
          path="/data-manage/:appID/internal"
          element={
            <React.Suspense fallback={<>...</>}>
              <DataManage />
            </React.Suspense>
          }
        />
        <Route
          path="/data-manage/:appID/external"
          element={
            <React.Suspense fallback={<>...</>}>
              <DataManage />
            </React.Suspense>
          }
        />
        <Route
          path="/data-manage/:appID/external/source"
          element={
            <React.Suspense fallback={<>...</>}>
              <About />
            </React.Suspense>
          }
        />
        <Route
          path="about"
          element={
            <React.Suspense fallback={<>...</>}>
              <About />
            </React.Suspense>
          }
        />
        <Route path="*" element={<NoMatch />} />
      </Route>
    </Routes>
  );
};
export default App;

function NoMatch() {
  return (
    <div>
      <h2>Need AppID!!! </h2>
      <h3>li: /data-manage/:appID/internal</h3>
      <p>
        <Link to="/">Go to the home page</Link>
      </p>
    </div>
  );
}
