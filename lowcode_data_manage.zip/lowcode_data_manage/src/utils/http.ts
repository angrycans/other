import type { AxiosError, AxiosInstance, AxiosRequestConfig, AxiosResponse } from "axios";
import axios from "axios";
import Cookies from "universal-cookie";
import { message } from "antd";

// 定义请求响应参数，不含data
interface Result {
  ErrCode: number;
  ErrText: string;
}
export const tokenCache = new Cookies();

export interface ResultData<T = any> extends Result {
  Data?: T;
  Rows?: T;
  ErrSeverity?: string;
  ExCode?: string;
}
const URL = "/digitalos-admin";
enum BaseURL {
  dip = "/digital-dip", // 大数据
}
enum RequestEnums {
  TIMEOUT = 1000 * 60, // 请求超时时间 默认 20s
  OVERDUE = 600, // 登录失效
  FAIL = 9999, // 请求失败
  SUCCESS = 1, // 请求成功
  SUCCESS1 = 200,
  MENU_SUCCESS = "0", // 菜单请求成功
}

const config = {
  // 默认地址
  baseURL: URL as string,
  // 设置超时时间
  timeout: RequestEnums.TIMEOUT as number,
  // 跨域时候允许携带凭证
  withCredentials: false,
  headers: {
    Authorization: `Bearer ${tokenCache.get("token")}`,
  },
};

class RequestHttp {
  // 定义成员变量并指定类型
  service: AxiosInstance;
  public constructor(config: AxiosRequestConfig) {
    // 实例化axios
    this.service = axios.create(config);

    /**
     * 请求拦截器
     * 客户端发送请求 -> [请求拦截器] -> 服务器
     * token校验: 接受服务器返回的token,存储到pinia/cookies本地储存当中
     */
    this.service.interceptors.request.use(
      (config: any) => {
        const token = tokenCache.get("access-token");
        if (config.url.includes("wind_tiger")) config.baseURL = "";
        if (config.url.includes("dip")) config.baseURL = BaseURL.dip;
        return {
          headers: {
            "access-token": token, // 请求头中携带token信息
            "Content-Type": "application/json",
            // Referer: 'http://localhost:3335/',
          },
          ...config,
        };
      },
      (error: AxiosError) => {
        // 请求报错
        Promise.reject(error);
      }
    );

    /**
     * 响应拦截器
     * 服务器换返回信息 -> [拦截统一处理] -> 客户端JS获取到信息
     */
    this.service.interceptors.response.use(
      (response: AxiosResponse) => {
        console.log("response", response);
        const { data } = response; // 解构
        if (data.code === RequestEnums.OVERDUE) {
          // 登录信息失效，应跳转到登录页面，并清空本地的token
          tokenCache.remove("access_token");
          location.replace("/login");
          return Promise.reject(data);
        }
        if (
          data?.code !== RequestEnums.SUCCESS &&
          data?.code !== RequestEnums.MENU_SUCCESS &&
          data?.code !== RequestEnums.SUCCESS1
        ) {
          // 全局错误信息拦截（防止下载文件得时候返回数据流，没有code，直接报错）
          message.error(data?.msg || data?.message); // 也可以使用组件提示报错信息
          return Promise.reject(data);
        }
        return data;
      },
      (error: AxiosError) => {
        const { response } = error;
        if (response) this.handleCode(response.status);

        if (!window.navigator.onLine) message.error("网络连接失败");
        // 可以跳转到错误页面，也可以不做操作
      }
    );
  }

  handleCode(code: number): void {
    switch (code) {
      default:
        message.error("请求失败");
        break;
    }
  }

  // 常用方法封装
  get<T>(url: string, params?: object): Promise<T> {
    return this.service.get(url, { params });
  }

  post<T>(url: string, params?: object, config?: AxiosRequestConfig): Promise<T> {
    return this.service.post(url, params, config);
  }
}

// 导出一个实例对象
export default new RequestHttp(config);
