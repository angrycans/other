import mitt from "mitt";

const Msg = mitt();

console.log("Msg init");
export default Msg;
