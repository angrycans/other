import {
  ApolloProvider,
  ApolloClient,
  InMemoryCache,
  HttpLink,
  ApolloLink,
  gql,
  concat,
  useQuery,
  useMutation,
} from "@apollo/client";

import { tokenCache } from "./http";
import { message } from "antd";

const httpLink = new HttpLink({ uri: "/digital/design/acans_test01/v2/graphql" });

const authMiddleware = new ApolloLink((operation, forward) => {
  // add the authorization to the headers
  operation.setContext(({ headers = {} }) => ({
    headers: {
      ...headers,
      authorization: `Bearer ${tokenCache.get("token")}`,
    },
  }));

  return forward(operation);
});

export const ApolloClientInstant = new ApolloClient({
  cache: new InMemoryCache(),
  link: concat(authMiddleware, httpLink),
});
