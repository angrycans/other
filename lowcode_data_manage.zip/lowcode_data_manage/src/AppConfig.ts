class AppConfig {
  static AppID = "";

  static setAppID(id: string) {
    this.AppID = id;
  }
}

export default AppConfig;
