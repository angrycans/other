import { Updater } from "use-immer";

export interface GraphqlOptionDescType {
  __typename: string;
  name: string;
  description: string | null;
  fields: Array<{
    __typename: string;
    name: string;
    description: string | null;
    args: Array<{
      __typename: string;
      name: string;
      description: string | null;
      type: {
        __typename: string;
        kind: string;
        name: string | null;
        ofType: {
          __typename: string;
          kind: string;
          name: string;
          ofType: null;
        };
      };
      defaultValue: null;
    }>;
  }>;
}

export interface TableField {
  enumeration: string;
  isSystem: boolean;
  defaultValue?: {
    args: any[];
    name: string;
  };
  name: string;
  isKey: boolean;
  caption: string;
  type: string;
  required: boolean;
}

export interface TableItem {
  name: string;
  caption: string;
  fields: TableField[]; // Replace with specific type if you have field details
  //data?: [];
}

export interface keyObjectType {
  [key: string]: {};
}

export interface StateType {
  count: number; //test
  app: {
    createTableModal: {
      open: boolean;
      loading: boolean;
    };
    createFieldModal: {
      open: boolean;
      loading: boolean;
    };
    tables: TableItem[];
    openTables?: TableItem[];
    openTablesActiveKey?: string;
    openTableDatas: { [key: string]: any[] };
    tablesOptionType: { Query?: GraphqlOptionDescType; Mutation?: GraphqlOptionDescType };
    enums: keyObjectType;
  };
}

// // 定义 context 值接口
export interface StateContextType {
  state: StateType;
  updateState: Updater<StateType>;
}

export interface ModifyTableType {
  name?: string;
  caption: string;
  itemOrder: string[];
  fields: {
    name: string;
    caption: string;
    type: string;
    defaultValue?: string;
    enumeration?: string;
  }[];
}
