import React, { useState, useEffect, useCallback, useMemo, useRef } from "react";
import { AgGridReact } from "ag-grid-react";
import {
  ColDef,
  CellEditRequestEvent,
  GetRowIdFunc,
  GetRowIdParams,
  CellValueChangedEvent,
  CellEditingStoppedEvent,
} from "ag-grid-community";
import "ag-grid-enterprise";
import "ag-grid-community/styles/ag-grid.css"; // Core CSS
import "ag-grid-community/styles/ag-theme-quartz.css"; // Theme
import moment from "moment";

import "./styles.css";

import ToolBar from "./toolbar";

import { useStore } from "../store";

import { useAsyncEffect } from "ahooks";
import * as API from "../api";
import * as Tools from "../tools";
import { Button, notification } from "antd";
import { TableItem, TableField } from "../types";
import { useDicData, useTableHeader } from "../hooks";

interface propsTypes {
  table: TableItem;
}

const Context = React.createContext({ name: "Default" });

const Grid: React.FC<propsTypes> = (props) => {
  const { state, updateState } = useStore();
  const [selectedRows, setSelectedRows] = useState([]);
  const gridRef = useRef(null);
  const [api, contextHolder] = notification.useNotification();
  const initcolDefs = useTableHeader(props.table);
  const [colDefs, setColDefs] = useState();
  const _ = useDicData(props.table);

  const defaultColDef = useMemo<ColDef>(() => {
    return {
      resizable: true,
      sortable: true,
      filter: false,
      //cellStyle: { textAlign: "left" },
      minWidth: 50,
      // headerCheckboxSelection: isFirstColumn,
      // checkboxSelection: isFirstColumn,
      // showDisabledCheckboxes: false,
    };
  }, []);

  const dataTypeDefinitions = useMemo(() => {
    return {
      // override `date` to handle custom date format `dd/mm/yyyy`
      date: {
        baseDataType: "date",
        extendsDataType: "date",
        // valueParser: (params: any) => {
        //   console.log("valueParser", params);
        //   if (params.newValue == null) {
        //     return null;
        //   }
        //   //const date = moment(params.newValue).toDate();

        //   return moment(params.value).format("YYYY-MM-DD");
        // },
        valueFormatter: (params: any) => {
          // convert to `dd/mm/yyyy`
          console.log("valueFormatter", params);
          return params.value == null ? "" : moment(params.value).format("YYYY-MM-DD");
        },
      },
    };
  }, []);

  const openNotification = (msg: string) => {
    api.success({
      message: `${msg}`,
      placement: "bottomRight",
      closeIcon: false,
      style: { height: "60px", width: "250px", backgroundColor: "black", color: "#fff" },
    });
  };

  const createTableData = async (table: TableItem) => {
    const ret = await API.getTableData(table);
    updateState((draft) => {
      draft.app.openTableDatas[props.table.name] = (ret as any).data[table.name + "s"];
      // const newData = (ret as any).data[table.name + "s"];

      // draft.app.openTableDatas[props.table.name] = newData.map((item: any, index: any) => {
      //   return { ...item, __id: index + 1 };
      // });
    });
  };

  useEffect(() => {
    console.log("Grid mount and refreshGrid", props.table, initcolDefs);
    setColDefs(initcolDefs);
    createTableData(props.table);
  }, [initcolDefs, props.table]);

  const onGridReady = (params?: any) => {
    console.log("Grid  onGridReady");

    // 现在可以安全地使用 grid API
  };

  useAsyncEffect(async () => {
    console.log("grid useAsyncEffect on mount");
  }, []);

  const onCellEditRequest = useCallback(async (event: CellEditRequestEvent) => {
    console.log("onCellEditRequest", event);
    const tablename = props.table.name;
    const rowIndex = event.rowIndex != undefined ? event.rowIndex : -1;
    const whereid = event.data.id;
    const field = event.colDef.field ? event.colDef.field : "";
    const value = event.newValue;
    let data = {} as any;

    data[field] = { set: value };
    const newData = { ...event.data };

    const option = Tools.getOptionFieldType(
      "updateOne",
      tablename,
      state.app.tablesOptionType.Mutation
    );
    const ret = await API.updateOneTableData({
      whereid,
      data,
      tablename,
      option,
    });
    console.log("ret", ret, `["${tablename}"][${rowIndex}]["${field}"]`);

    if (ret.data) {
      updateState((draft) => {
        draft.app.openTableDatas[`${tablename}`].find((item) => item.id == whereid)[`${field}`] =
          value;
      });
    }

    const tx = {
      update: [newData],
    };
    event.api.applyTransaction(tx);
  }, []);

  const getRowId = useMemo<GetRowIdFunc>(() => {
    return (params: GetRowIdParams) => {
      return params.data.id;
    };
  }, []);

  const onSelectionChanged = useCallback(() => {
    // const selectedRows =;
    setSelectedRows((gridRef.current as any).api.getSelectedRows());
    console.log("onSelectionChanged", (gridRef.current as any).api.getSelectedRows());
  }, []);

  const deleteRows = async () => {
    const data = selectedRows.map((item: any) => item.id);
    const option = Tools.getOptionFieldType(
      "deleteMany",
      props.table.name,
      state.app.tablesOptionType.Mutation,
      "where"
    );
    //console.log("deleteRows", data, option);

    const ret = await API.deleteManyTableData({ option, table: props.table, data });
    console.log("deleteManyTableData", ret);

    updateState((draft) => {
      //draft.app.openTableDatas[props.table.name].push(newRowData);
      draft.app.openTableDatas[props.table.name] = draft.app.openTableDatas[
        props.table.name
      ].filter((item) => !data.includes(item.id));
    });
    openNotification("删除数据成功。");
  };

  return (
    <>
      <ToolBar table={props.table} />
      {contextHolder}
      {/* <div>
        Count: {state?.count}
        <Button onClick={() => {}}>test</Button>
      </div> */}

      <div
        className={"ag-theme-quartz"}
        style={{ position: "relative", width: "100%", flex: 1, padding: "10px" }}
      >
        <div
          className="fixed-delete-div"
          style={{ display: selectedRows.length ? "flex" : "none" }}
        >
          {selectedRows.length}
          <span style={{ margin: "0 13px 0 5px" }}>记录</span>
          <Button
            type="primary"
            danger
            size="small"
            onClick={() => {
              deleteRows();
            }}
          >
            删除记录
          </Button>
        </div>
        <AgGridReact
          ref={gridRef}
          rowSelection="multiple"
          readOnlyEdit={true}
          suppressRowClickSelection={true}
          defaultColDef={defaultColDef}
          columnDefs={colDefs}
          rowBuffer={9999}
          stopEditingWhenCellsLoseFocus={true}
          rowData={state.app.openTableDatas[props.table.name]}
          getRowId={getRowId}
          onCellEditRequest={onCellEditRequest}
          onSelectionChanged={onSelectionChanged}
          onGridReady={onGridReady}

          //onCellEditingStopped={onCellValueChanged}
          //dataTypeDefinitions={dataTypeDefinitions as any}
        />
      </div>
    </>
  );
};

export default Grid;
