interface propsTypes {
  type: string; //"tablabel" ,"label"
  text: string;
  value: string;
}

const FormilyLabel: React.FC<propsTypes> = (props) => {
  return props.type == "label" ? (
    <div onClick={(props as any).onClick}>{props.value}</div>
  ) : (
    <div
      style={{
        marginBottom: "0px",
        marginTop: "8px",
        borderBottom: "1px solid #ccc",
        paddingBottom: "0px",
      }}
    >
      <span style={{ borderBottom: "1px solid #000", marginBottom: "0px", paddingBottom: "2px" }}>
        {props.text}
      </span>
    </div>
  );
};

export default FormilyLabel;
