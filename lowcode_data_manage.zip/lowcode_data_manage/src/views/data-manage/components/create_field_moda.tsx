import React, { useState } from "react";
import { Button, Modal } from "antd";
import { DownCircleTwoTone, DownCircleFilled, CloseOutlined } from "@ant-design/icons";

import {
  Input,
  FormItem,
  FormButtonGroup,
  Submit,
  FormTab,
  ArrayTable,
  FormLayout,
  PreviewText,
  ArrayTabs,
  ArrayItems,
  Select,
  Space,
} from "@formily/antd-v5";

import {
  createForm,
  FormPath,
  onFieldReact,
  Field,
  FieldDataSource,
  onFieldValueChange,
} from "@formily/core";
import { FormProvider, createSchemaField, FormConsumer } from "@formily/react";
import { action } from "@formily/reactive";

import FormilyLabel from "./formily-label";
import FormilyArrayItem from "./formily_arrayitem";
import { useStore } from "../store";
import * as API from "../api";
import { useModifyField, useModifyTable } from "../hooks";

const SchemaField = createSchemaField({
  components: {
    Input,
    FormTab,
    FormItem,
    ArrayTable,
    FormLayout,
    PreviewText,
    Submit,
    ArrayTabs,
    ArrayItems,
    FormilyLabel,
    FormilyArrayItem,
    Button,
    Select,
    DownCircleTwoTone,
    DownCircleFilled,
    CloseOutlined,
    Space,
  },
});

const getDicList = async (field: Field) => {
  return API.getDicList();
};
const getDicData = async (field: Field, id: string) => {
  console.log("getDicData call ", id);
  return API.getDicData(id);
};

const schema_field = {
  type: "object",
  properties: {
    table_sub_layout_name: {
      type: "void",
      "x-component": "FormLayout",
      "x-component-props": {
        style: {
          display: "flex",
          flexDirection: "column",
          padding: "0px 0px 0px 0",
          background: "#fff",
          //height: "60px",
        },
      },
      properties: {
        item_name: {
          type: "string",
          title: "字段名",
          required: true,
          "x-validator": [
            {
              pattern: "^[A-Za-z].*",
              message: "首字母必须是英文",
            },
            {
              validator: (val: string) => val.toLowerCase() != "id",
              message: "ID关键字不可以使用",
            },
          ],

          "x-decorator": "FormItem",
          "x-decorator-props": {
            layout: "vertical",
            style: {
              //flex: "1",
              //margin: "0 0 0 0",
            },
          },
          "x-component": "Input",
          "x-component-props": {
            placeholder: "field_name",
            style: {
              width: " 300px",
            },
            //focus: true,
          },
        },
        item_type: {
          type: "string",
          title: "字段类型",
          "x-decorator": "FormItem",
          "x-decorator-props": {
            layout: "vertical",
            style: {
              flex: "1",
              margin: "0 0 0 0",
              border: "0px solid #ccc",
              padding: "5px 8px 5px 8px",
              background: "rgba(0, 0, 0, 0.04)",
            },
          },
          "x-component": "Select",
          enum: [
            { label: "文本", value: "String" },
            { label: "数字", value: "int" },
            { label: "小数", value: "double" },
            { label: "时间", value: "Datatime" },
            { label: "布尔", value: "boolean" },
            { label: "枚举", value: "Enum" },
          ],
          "x-component-props": {
            style: {
              width: "300px",
            },
          },
          "x-reactions": {
            target: ".item_default",
            // dependencies: [".item_type", ".options"],
            fulfill: {
              run: `
              if ($self.value!='Enum'){
                $target.setComponent("Input")
              }else{
                $target.setComponent("Select")
              }
                
                `,
            },
          },
        },
      },
    },
    table_sub_layout_enum_option: {
      type: "void",
      "x-decorator": "FormItem",
      "x-decorator-props": {
        style: { margin: 0 },
      },
      "x-component": "FormLayout",
      "x-component-props": {
        style: {
          border: "0px solid #ccc",
          padding: "5px 8px 5px 8px",
          background: "rgba(0, 0, 0, 0.04)",
          // margin: 0,
        },
      },
      "x-reactions": {
        //target: "item_type",
        dependencies: [".item_type"],
        fulfill: {
          state: {
            hidden: "{{$deps[0]!='Enum'}}",
          },
        },
      },
      properties: {
        item_select_dic: {
          type: "string",
          title: "选择字典",
          "x-decorator": "FormItem",
          "x-decorator-props": {
            layout: "vertical",
            style: {
              flex: "1",
              marginBottom: "0px",
            },
          },
          "x-component": "Select",
          enum: [],
          "x-component-props": {
            style: {
              width: "200px",
            },
          },

          "x-reactions": [
            {
              //target: "field_items.*.item_type",
              effects: ["onFieldInit"],
              fulfill: {
                run: `
                console.log("enum_select_dic x-reactions onFieldInit");
                agetDicList=async()=>{
                  const ret=await getDicList()
                  console.log("enum_select_dic x-reactions ret",ret)

                  if (ret.code == 1 && ret.datas.modules.length > 0 && ret.datas.modules[0].dics.length > 0) {
                    const data = ret.datas.modules[0].dics.map((item) => {
                      return {
                        label: item.caption,
                        value: item.id,
                      };
                    });
                    $self.dataSource = data;
                  }
                }
                agetDicList()
                        `,
              },
            },
            {
              // target: "field_items.*.item_type",
              effects: ["onFieldInputValueChange"],
              fulfill: {
                run: `
                console.log("enum_select_dic x-reactions onFieldInputValueChange");
                                   
                agetDicData=async()=>{
                  console.log("enum_select_dic x-reactions ret",$self.value)

                  const ret=await getDicData($self,$self.value)
                  console.log("enum_select_dic x-reactions ret",ret)
                  if (ret.code == 1 && ret.datas.dic.items.length > 0) {
                    const data = ret.datas.dic.items.map((item) => {
                      return {
                        label: item.content,
                        value: item.code,
                      };
                    });
        
                 
                    $self.query(".item_default").take().dataSource = data;
                  }
                 
                }
                agetDicData()
                        `,
              },
            },
          ],
        },
      },
    },
    table_sub_layout2: {
      type: "void",
      "x-component": "FormLayout",
      "x-component-props": {
        style: {
          display: "flex",
          justifyContent: "flex-start",
          border: "0px solid #ccc",
          padding: "5px 8px 5px 8px",
          background: "rgba(0, 0, 0, 0.04)",
          height: "60px",
        },
      },
      properties: {
        item_nullable: {
          type: "string",
          title: "字段是否为空",
          "x-decorator": "FormItem",
          "x-decorator-props": {
            layout: "vertical",
            style: {
              //flex: "0.35",
              width: "200px",
            },
          },
          "x-component": "Select",
          enum: [
            { label: "是", value: "1" },
            { label: "否", value: "0" },
          ],
          default: "No",
          "x-component-props": {
            style: {
              // width: 200,
            },
          },
        },
      },
    },
    table_sub_layout3: {
      type: "void",
      "x-component": "FormLayout",
      "x-component-props": {
        style: {
          display: "flex",
          justifyContent: "flex-start",
          border: "0px solid #ccc",
          //borderRadius: "8px",
          padding: "5px 8px 10px 8px",
          //marginBottom: "12px",
          background: "rgba(0, 0, 0, 0.04)",
          height: "60px",
        },
      },
      properties: {
        item_isdefault: {
          type: "string",
          title: "是否有默认值",
          "x-decorator": "FormItem",
          "x-decorator-props": {
            layout: "vertical",
            style: {
              flex: "0.5",
            },
          },
          "x-component": "Select",
          enum: [
            { label: "否", value: "0" },
            { label: "有", value: "1" },
          ],
          default: "No",
          "x-reactions": {
            target: "item_default",
            // dependencies: [".item_isdefault"],
            fulfill: {
              run: `
                
                `,
              state: {
                hidden: "{{$self.value!='1'}}",
              },
            },
          },
          "x-component-props": {
            style: {
              width: 200,
            },
          },
        },
        item_default: {
          type: "string",
          title: "默认值",
          "x-decorator": "FormItem",
          "x-decorator-props": {
            layout: "vertical",
            style: {
              flex: "0.5",
            },
          },
          "x-component": "Input",
          "x-component-props": {
            style: {
              width: 200,
            },
          },
          "x-reactions": {
            //target: "field_items.*.options",
            dependencies: [".options"],
            fulfill: {
              run: `
                    
                   
                 `,
            },
          },
        },
      },
    },
    table_sub_layout4: {
      type: "void",
      "x-component": "FormLayout",
      "x-component-props": {
        style: {
          display: "flex",
          justifyContent: "flex-start",
          padding: "2px 0 0px 8px",
          //marginBottom: "12px",
          background: "#fff",
        },
      },
    },
  },
};

const CreateFieldModal: React.FC = () => {
  const { state, updateState } = useStore();
  const { modifyField } = useModifyField();

  const initvalue = {
    values: {
      item_name: "",
      item_type: "String",
      item_nullable: "1",
      item_isdefault: "0",
      item_default: "",
      item_select_dic: "",
    },
  };

  const form = createForm(initvalue);

  const setOpen = (_open: boolean) => {
    updateState((draft) => {
      draft.app.createFieldModal.open = _open;
    });
  };

  const handleOk = () => {
    form.submit((data) => {
      console.log(data);
      modifyField(data);
      form.values = initvalue.values;

      setOpen(false);
    });
  };

  const handleCancel = () => {
    console.log("handleCancel");
    form.values = initvalue.values;
    setOpen(false);
  };

  return (
    <Modal
      open={state?.app?.createFieldModal.open}
      title={"创建字段"}
      onOk={handleOk}
      destroyOnClose={true}
      onCancel={handleCancel}
      width={"500px"}
      footer={[
        <Button
          key="cancel"
          type="default"
          // loading={state?.app?.createTableModal.loading}
          onClick={handleCancel}
        >
          取消
        </Button>,
        <Button
          key="ok"
          type="primary"
          //loading={state?.app?.createTableModal.loading}
          onClick={handleOk}
        >
          创建
        </Button>,
      ]}
    >
      <FormProvider form={form}>
        <SchemaField schema={schema_field} scope={{ getDicList, getDicData }} />
      </FormProvider>
    </Modal>
  );
};

export default CreateFieldModal;
