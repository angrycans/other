import React, { useEffect, useState, useRef } from "react";

import {
  MenuFoldOutlined,
  MenuUnfoldOutlined,
  UploadOutlined,
  UserOutlined,
  VideoCameraOutlined,
  DownOutlined,
  SmileOutlined,
  PlusOutlined,
} from "@ant-design/icons";
import type { MenuProps } from "antd";
import { Layout, Menu, Button, theme, Dropdown, Space } from "antd";

import { useStore } from "../store";
import { TableItem } from "../types";
import { useAddOpenTables } from "../hooks";

const TablesMenu: React.FC = () => {
  const { state, updateState } = useStore();
  const _ = useAddOpenTables();

  // const addOpenTables2 = (pitem: TableItem) => {
  //   console.log("addOpenTables2", state.app.openTables, pitem);

  //   const existingItemIndex = state.app.openTables
  //     ? state.app.openTables.findIndex((item) => item.name === pitem.name)
  //     : -1;
  //   console.log("existingItemIndex", existingItemIndex);
  //   if (existingItemIndex == -1) {
  //     updateState((draft) => {
  //       if (!draft.app.openTables) {
  //         draft.app.openTables = [];
  //       }

  //       draft.app.openTables?.push(pitem);
  //       draft.app.openTablesActiveKey = pitem.name;
  //     });
  //   } else {
  //     updateState((draft) => {
  //       draft.app.openTablesActiveKey = pitem.name;

  //       console.log("openTablesActiveKey", pitem.name);
  //     });
  //   }
  // };

  useEffect(() => {
    console.log("TablesMenu willmount");
    return () => {
      console.log("TablesMenu unmount");
    };
  }, []);

  return (
    <>
      <Menu
        style={{ height: "100%" }}
        // mode="inline"
        selectable={false}
        items={state.app?.tables?.map((item, index) => {
          return {
            key: index + "",
            label: (
              <div
                onClick={() => {
                  console.log("menu clicked", item);

                  updateState((draft) => {
                    draft.app.openTablesActiveKey = item.name;
                  });
                }}
              >
                {item.caption}
              </div>
            ),
          };
        })}
      />
    </>
  );
};

export default TablesMenu;
