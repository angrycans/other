import React, { useState } from "react";
import { useStore } from "../store";
import { PlusOutlined } from "@ant-design/icons";

const AgHeaderAddfield: React.FC = () => {
  const { updateState } = useStore();

  return (
    <>
      <PlusOutlined
        onClick={() => {
          console.log("AgHeaderAddfield click");
          updateState((draft) => {
            draft.app.createFieldModal.open = true;
          });
        }}
      />
    </>
  );
};

export default AgHeaderAddfield;
