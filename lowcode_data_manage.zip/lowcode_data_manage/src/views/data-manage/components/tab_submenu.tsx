import React, { useEffect, useState, useRef } from "react";

import {
  MenuFoldOutlined,
  MenuUnfoldOutlined,
  UploadOutlined,
  UserOutlined,
  VideoCameraOutlined,
  DownOutlined,
  SmileOutlined,
  PlusOutlined,
  EditOutlined,
  DeleteOutlined,
  CloseOutlined,
} from "@ant-design/icons";
import type { MenuProps } from "antd";
import {
  Layout,
  Menu,
  Button,
  theme,
  Modal,
  Dropdown,
  Space,
  message,
  Popconfirm,
  App,
} from "antd";

import { useStore } from "../store";
import { useDeleteTable } from "../hooks";

interface propsTypes {
  table_name: string;
}

const TabSubMenu: React.FC<propsTypes> = (props) => {
  const { state, updateState } = useStore();
  const [visiable, setVisiable] = useState("none");
  const { deleteTable } = useDeleteTable();

  const menu_items: MenuProps["items"] = [
    {
      key: "1",
      icon: <EditOutlined />,
      label: (
        <>
          <a
            target="_blank"
            onClick={() => {
              console.log("TabSubMenu click", props.table_name);
            }}
          >
            重命名
          </a>
        </>
      ),
    },
    {
      key: "2",
      icon: <PlusOutlined />,
      label: (
        <>
          <a
            target="_blank"
            onClick={() => {
              console.log("TabSubMenu click", props.table_name);
            }}
          >
            创建表格
          </a>
        </>
      ),
    },
    {
      key: "3",
      icon: <PlusOutlined />,
      label: (
        <>
          <a
            target="_blank"
            onClick={() => {
              console.log("TabSubMenu click", props.table_name);
            }}
          >
            导出CSV
          </a>
        </>
      ),
    },
    {
      key: "4",
      icon: <CloseOutlined />,
      label: (
        <>
          <a
            target="_blank"
            onClick={() => {
              console.log("TabSubMenu click", props.table_name);
            }}
          >
            关闭标签
          </a>
        </>
      ),
    },
    {
      key: "5",
      icon: <CloseOutlined />,
      label: (
        <>
          <a
            target="_blank"
            onClick={() => {
              console.log("TabSubMenu click", props.table_name);
            }}
          >
            关闭其他标签
          </a>
        </>
      ),
    },
    {
      key: "6",
      icon: <CloseOutlined />,
      label: (
        <>
          <a
            target="_blank"
            onClick={() => {
              console.log("TabSubMenu click", props.table_name);
            }}
          >
            关闭右边的标签
          </a>
        </>
      ),
    },
    {
      key: "7",
      danger: true,
      icon: <DeleteOutlined />,

      label: (
        <>
          <a
            target="_blank"
            onClick={() => {
              console.log("TabSubMenu click", props.table_name);

              Modal.confirm({
                title: "",
                content: "确定要删除该表吗?",

                onOk: async () => {
                  await deleteTable(props.table_name);
                },
                onCancel: () => {},
              });
            }}
          >
            删除表格
          </a>
        </>
      ),
    },
  ];

  useEffect(() => {
    console.log("TabSubMenu", props, state.app.openTablesActiveKey);
    state.app.openTablesActiveKey == props.table_name
      ? setVisiable("contents")
      : setVisiable("none");
  }, [state.app.openTablesActiveKey]);

  return (
    <div style={{ display: visiable }}>
      <Dropdown trigger={["click"]} menu={{ items: menu_items }}>
        <DownOutlined style={{ margin: "2px 10px" }} />
      </Dropdown>
    </div>
  );
};

export default TabSubMenu;
