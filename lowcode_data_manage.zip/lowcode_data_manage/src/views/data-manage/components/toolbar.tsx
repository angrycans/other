import React, { useEffect, useState } from "react";
import { Button, Flex, Space, Dropdown, message } from "antd";
import {
  DownOutlined,
  UserOutlined,
  ReloadOutlined,
  FilterOutlined,
  SortAscendingOutlined,
} from "@ant-design/icons";
import type { MenuProps } from "antd";
import { useStore } from "../store";
import Msg from "../../../utils/mitt";
import * as API from "../api";
import * as Tools from "../tools";
import { useUpdateTable } from "../hooks";
import { TableItem } from "../types";

interface propsTypes {
  table: TableItem;
}

const ToolBar: React.FC<propsTypes> = (props) => {
  const { state, updateState } = useStore();
  const { updateTable } = useUpdateTable();

  const items: MenuProps["items"] = [
    {
      label: "1st menu item",
      key: "1",
      icon: <UserOutlined />,
    },
    {
      label: "2nd menu item",
      key: "2",
      icon: <UserOutlined />,
    },
    {
      label: "3rd menu item",
      key: "3",
      icon: <UserOutlined />,
      danger: true,
    },
    {
      label: "4rd menu item",
      key: "4",
      icon: <UserOutlined />,
      danger: true,
      disabled: true,
    },
  ];

  const handleMenuClick: MenuProps["onClick"] = (e) => {
    message.info("Click on menu item.");
    console.log("click", e);
  };

  const menuProps = {
    items,
    onClick: handleMenuClick,
  };

  useEffect(() => {
    console.log("ToolBar willmount");
    return () => {
      console.log("ToolBar unmount");
    };
  }, []);

  return (
    <div
      style={{
        display: "flex",
        justifyContent: "space-between",
        margin: "10px 10px 0px 10px",
      }}
    >
      <div>
        <Space>
          <Button
            onClick={async () => {
              // const newRowData = props.table.fields.reduce((obj, column) => {
              //   (obj as any)[column.name] = column.defaultValue ? column.defaultValue.name : null;
              //   return obj;
              // }, {});

              // console.log("add rowdata", props.table, newRowData);
              const option = Tools.getOptionFieldType(
                "createOne",
                props.table.name,
                state.app.tablesOptionType.Mutation
              );
              const ret = await API.createOneTableData({ option, table: props.table });
              const newRowData = ret.data[option.optionname];
              console.log("newRowData", newRowData);
              updateState((draft) => {
                draft.app.openTableDatas[props.table.name].push(newRowData);
              });
            }}
          >
            新增记录
          </Button>
        </Space>
        {/* <Dropdown menu={menuProps}>
          <Button>
            <Space>
              导入CSV
              <DownOutlined />
            </Space>
          </Button>
        </Dropdown>
        <Button type="text" icon={<FilterOutlined />}>
          筛选
        </Button>
        <Button type="text" icon={<SortAscendingOutlined />}>
          排序
        </Button> */}
      </div>
      <div>
        <Button
          type="text"
          onClick={async () => {
            await updateTable(props.table.name);
            //Msg.emit("GRID::REFRESH", props.table);
          }}
          icon={<ReloadOutlined />}
        >
          刷新
        </Button>

        <Button type="text">
          {state.app.openTableDatas[props.table.name]
            ? state.app.openTableDatas[props.table.name].length
            : "0"}
          记录
        </Button>
      </div>
    </div>
  );
};

export default ToolBar;
