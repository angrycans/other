import React, { useRef } from "react";

import { ArrayItems } from "@formily/antd-v5";

import { FormConsumer, useField, useForm } from "@formily/react";

interface propsTypes {
  //type: string; //"tablabel" ,"label"
  // value: string;
  pathname: string;
  style_active: boolean;
}

interface ItemWidgetPropsTypes {
  columns: any;
  style_active: boolean;
}

const ItemWidget: React.FC<ItemWidgetPropsTypes> = (props) => {
  const { columns, style_active } = props;
  // const index = ArrayItems.useIndex();
  // const record = ArrayItems.useRecord();

  // console.log("ItemWidget props columns", props, columns);
  const childs = columns.map((item: any, idx: number) => {
    return (
      <div key={"ItemWidgetItem" + idx} style={{ width: item.width, padding: "0 6px" }}>
        {item.value}
      </div>
    );
  });
  return (
    <div
      key={columns.key}
      style={
        style_active
          ? {
              display: "flex",
              borderRadius: "8px",
              border: "1px solid #eaeaea",
              background: "#eaeaea",
            }
          : {
              display: "flex",
            }
      }
    >
      {childs}
    </div>
  );
};

const FormilyArrayItem: React.FC<propsTypes> = (props) => {
  const index = ArrayItems.useIndex();
  const form = useForm();
  //const collapseLayout = useRef(null);

  //console.log("form", form);

  const handleClick = () => {
    const table_layout0 = form.query(`${props.pathname}.${index}.table_layout`).take();
    //const visible = (table_layout0 as any).visible;
    const count = form.values[props.pathname].length;
    (table_layout0 as any).setDisplay("visible");
    (form.query(`${props.pathname}.${index}.item_readony`).take() as any).setComponentProps({
      style_active: true,
    });

    for (let i = 0; i < count; i++) {
      if (i == index) continue;
      (form.query(`${props.pathname}.${i}.table_layout`).take() as any).setDisplay("hidden");

      // console.log(form.query(`${props.pathname}.${i}.item_readony`).take() as any);
      (form.query(`${props.pathname}.${i}.item_readony`).take() as any).setComponentProps({
        style_active: false,
      });
    }
  };

  return (
    <FormConsumer>
      {(form) => {
        if (form.values[props.pathname]) {
          const obj = form.values[props.pathname][index];
          //console.log("props.pathname", props.pathname, obj);
          //delete obj.options;
          let columns: any = [];
          Object.keys(obj as any).forEach((objname, idx) => {
            if (!(obj[objname] instanceof Array)) {
              const field = form.query(`${props.pathname}.${index}.${objname}`).take() as any;
              // console.log(
              //   "FormilyArrayItem obj",
              //   obj[objname],
              //   `${props.pathname}.${index}.${objname}`
              // );
              //console.log("FormilyArrayItem caption", field, field && field.dataSource);

              const getVal = () => {
                if (field && field.dataSource) {
                  const finditem = field.dataSource.find((item: any) => item.value == obj[objname]);
                  // console.log("FormilyArrayItem finditem", finditem);
                  return finditem ? finditem.label : "";
                } else {
                  return obj[objname];
                }
              };

              //console.log("FormilyArrayItem getVal", getVal());

              columns.push({
                key: "FormilyArrayItem" + idx,
                width: "20%",
                value: getVal(),
              });
            }
          });

          //console.log("ItemWidget columns", columns);
          return (
            <div onClick={handleClick} style={{}}>
              <ItemWidget columns={columns} style_active={props.style_active} />
            </div>
          );
        } else {
          return <div>{`${props.pathname} not found`}</div>;
        }
      }}
    </FormConsumer>
  );
};

export default FormilyArrayItem;
