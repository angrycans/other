import { useStore } from "./store";
import * as API from "./api";
import { GraphqlOptionDescType } from "./types";

const getOptionFieldType = (
  option: string,
  tablename: string,
  params?: GraphqlOptionDescType,
  childtype?: "where" | "data"
) => {
  const optionname = `${option}${tablename.charAt(0).toUpperCase() + tablename.slice(1)}`;

  console.log("getOptionFieldType r0", optionname, params);

  let r1 = params?.fields.find((item) => {
    return item.name == optionname;
  });

  console.log("getOptionFieldType r1", r1);

  let r2;
  if (childtype === "where") {
    r2 = r1?.args.find((item2) => item2.name == "where")?.type.name;
  } else {
    r2 = r1?.args.find((item2) => item2.name == "data")?.type.ofType.name;
  }

  console.log("getOptionFieldType r2", r2);

  let optiontype = r2;

  return { optionname, optiontype: optiontype ? optiontype : "" };
};

const toAgGridEditorType = (type: string): { type: string; editor: string } => {
  switch (type) {
    case "int": {
      return { type: "number", editor: "agNumberCellEditor" };
      break;
    }
    case "long": {
      return { type: "number", editor: "agNumberCellEditor" };

      break;
    }
    case "double": {
      return { type: "number", editor: "agNumberCellEditor" };

      break;
    }
    case "Enum": {
      return { type: "text", editor: "agRichSelectCellEditor" };

      break;
    }
    case "boolean": {
      return { type: "boolean", editor: "agCheckboxCellEditor" };

      break;
    }
    case "Datetime": {
      return { type: "dateString", editor: "agDateStringCellEditor" };

      break;
    }

    case "String": {
      return { type: "text", editor: "agTextCellEditor" };

      break;
    }
    case "File": {
      return { type: "text", editor: "agTextCellEditor" };

      break;
    }
    case "User": {
      return { type: "text", editor: "agTextCellEditor" };

      break;
    }
    default:
      return { type: "text", editor: "agTextCellEditor" };
  }
};

// const getAndInitDicData = async (id: string) => {
//   const { state, updateState } = useStore();
//   const ret = await API.getDicData(id);
//   if (ret.code) {
//     console.log("getAndInitDicData", state);
//     updateState(ret.data.datas);
//     return ret.data.datas;
//   }

//   return "";
// };

export { getOptionFieldType, toAgGridEditorType };
