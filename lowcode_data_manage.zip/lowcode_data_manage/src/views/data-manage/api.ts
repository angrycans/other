import axios from "../../utils/http";
import { ApolloClientInstant } from "../../utils/graphql";
import { gql } from "@apollo/client";
import { ModifyTableType, TableItem } from "./types";
import AppConfig from "../../AppConfig";

const getFieldsByTable = (tablename: string) => {
  //return axios.get<any>("/digital/design/logic/systemVariable.do");
  return axios.get<any>(`/digital/design/${AppConfig.AppID}/v2/fields/` + tablename);
};

const getDicList = () => {
  return axios.get<any>("/digital/design/dic/list.do", { app: AppConfig.AppID });
};

const getDicData = (id: string) => {
  return axios.post<any>("/digital/design/dic/get.do", { app: AppConfig.AppID, id });
};

const getTables = () => {
  return axios.get<any>(`/digital/design/${AppConfig.AppID}/v2/tables`);
};

const getEntries = () => {
  return axios.get<any>(`/digital/design/${AppConfig.AppID}/v2/entries`);
};

const modifyTable = (tablejson: ModifyTableType) => {
  return axios.post<any>(`/digital/design/${AppConfig.AppID}/v2/modifyTable`, tablejson);
};

const deleteTable = (tablename: string) => {
  return axios.post<any>(`/digital/design/${AppConfig.AppID}/v2/deleteTable/${tablename}`);
};

const getTableData = (table: TableItem) => {
  const query = `
                query {
                  ${table.name}s {
                    ${table.fields.map((field) => field.name).join("\n")}
                  }
                }
              `;
  console.log("getTableDataByname", query);
  return ApolloClientInstant.query({
    query: gql`
      ${query}
    `,
    fetchPolicy: "network-only",
  });
};

const updateOneTableData = (params: {
  option: { optionname: string; optiontype: string };
  tablename: string;
  whereid: string;
  data: {};
}) => {
  const query = `
                mutation updateOne($var1:${params.option.optiontype}!){
                  ${params.option.optionname}(
                    data:$var1,
                      where:{id:"${params.whereid}"}){id}}
              `;
  const variables = { var1: params.data };
  console.log("updateData", query, variables);
  return ApolloClientInstant.mutate({
    mutation: gql`
      ${query}
    `,
    variables,
  });
};

const createOneTableData = (params: {
  option: { optionname: string; optiontype: string };
  table: TableItem;
}) => {
  const query = `
                mutation createOne($var1:${params.option.optiontype}!){
                  ${params.option.optionname}(
                    data:$var1){${params.table.fields.map((field) => field.name).join("\n")}}}
              `;
  const variables = { var1: {} };
  console.log("createOneTableData", query, variables);
  return ApolloClientInstant.mutate({
    mutation: gql`
      ${query}
    `,
    variables,
  });
};

const deleteManyTableData = (params: {
  option: { optionname: string; optiontype: string };
  table: TableItem;
  data: string[];
}) => {
  const query = `
                mutation deleteMany($var1:${params.option.optiontype}!){
                  ${params.option.optionname}(
                    where:$var1){count}}
              `;
  const variables = { var1: { id: { in: params.data } } };
  console.log("deleteManyTableData", query, variables);
  return ApolloClientInstant.mutate({
    mutation: gql`
      ${query}
    `,
    variables,
  });
};

const getALlTableOptionType = (params: "Query" | "Mutation") => {
  const query = `
  query IntrospectionQuery {
    __type (name: "${params}") {  
      ...FullType
    }
  }
  
  fragment FullType on __Type {
    name
    description
    fields(includeDeprecated: true) {
      name
      description
      args {
        ...InputValue
      }
    }
  }
  
  fragment InputValue on __InputValue {
    name
    description
    type {
      ...TypeRef
    }
    defaultValue
  }
  
  fragment TypeRef on __Type {
    kind
    name
    ofType {
      kind
      name
      ofType {
        kind
        name
        ofType {
          kind
          name
          ofType {
            kind
            name
            ofType {
              kind
              name
              ofType {
                kind
                name
                ofType {
                  kind
                  name
                }
              }
            }
          }
        }
      }
    }
  }
              `;
  //console.log("updateData", query);
  return ApolloClientInstant.query({
    query: gql`
      ${query}
    `,
    fetchPolicy: "network-only",
  });
};

// ApolloClientInstant.query({
//   query: gql`
//     query UserQuery {
//       t1JHLR98G8H08_IMPOTVs {
//         id
//         iIMPOU0
//       }
//     }
//   `,
// }).then((result) => console.log("ApolloClientInstant result", result));

// ApolloClientInstant.query({
//   query: gql`
//     query UserQuery($order: [T1JHLR98G8H08_ASCOrderByInput!]) {
//       t1JHLR98G8H08_ASCs(orderBy: $order) {
//         id
//         iEND
//         iDIV
//       }
//     }
//   `,
//   variables: { order: [{ iEND: { sort: "asc" } }] },
// }).then((result) => console.log("ApolloClientInstant result", result));

// const ret = useMutation(
//   gql`
//   mutation BooksQuery{deleteOneT1JHLR98G8H08_A1(where:{id:"1L54H38S8G0E"}){id}
//   `
// );

// ApolloClientInstant.query({
//   query: gql`
//   mutation
//    BooksQuery{deleteOneT1JHLR98G8H08_A1(where:{id:"1L54H38S8G0E"}){id}

//   `,
//   variables: { pid: "1L54H38S8G0E" },
// }).then((result) => console.log("result2", result));

// console.log("graphql init....");

// ApolloClientInstant.query({
//   query: gql`
//     query UserQuery($order: [T1JHLR98G8H08_ASCOrderByInput!]) {
//       t1JHLR98G8H08_ASCs(orderBy: $order) {
//         id
//         iEND
//         iDIV
//       }
//     }
//   `,
//   variables: { order: [{ iEND: { sort: "asc" } }] },
// }).then((result) => console.log("graphql result", result));

// const query = `
// query UserQuery($order: [T1JHLR98G8H08_ASCOrderByInput!]) {
//   t1JHLR98G8H08_ASCs(orderBy: $order) {
//     id
//     iEND
//     iDIV
//   }
// }
// `;

// const { loading, error, data } = useQuery(gql(query), {
//   variables: { order: [{ iEND: { sort: "asc" } }] },
// });

export {
  getFieldsByTable,
  getTables,
  getEntries,
  getTableData,
  updateOneTableData,
  createOneTableData,
  getALlTableOptionType,
  deleteManyTableData,
  getDicData,
  getDicList,
  modifyTable,
  deleteTable,
};
