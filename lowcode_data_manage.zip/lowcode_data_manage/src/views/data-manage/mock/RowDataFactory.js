import RefData from "./RefData";

export default class RowDataFactory {
  createRowData() {
    const rowData = [];

    for (let i = 0; i < 200; i++) {
      const countryData = RefData.COUNTRIES[i % RefData.COUNTRIES.length];
      rowData.push({
        name:
          RefData.FIRST_NAMES[i % RefData.FIRST_NAMES.length] +
          " " +
          RefData.LAST_NAMES[i % RefData.LAST_NAMES.length],
        skills: {
          android: Math.random() < 0.4,
          html5: Math.random() < 0.4,
          mac: Math.random() < 0.4,
          windows: Math.random() < 0.4,
          css: Math.random() < 0.4,
        },
        dob: RefData.DOB[i % RefData.DOB.length],
        address: RefData.ADDRESSES[i % RefData.ADDRESSES.length],
        years: Math.round(Math.random() * 100),
        proficiency: Math.round(Math.random() * 100),
        country: countryData.country,
        continent: countryData.continent,
        language: countryData.language,
        mobile: this.createRandomPhoneNumber(),
        landline: this.createRandomPhoneNumber(),
      });
    }

    return rowData;
  }

  createRandomPhoneNumber() {
    let result = "+";
    for (let i = 0; i < 12; i++) {
      result += Math.round(Math.random() * 10);
      if (i === 2 || i === 5 || i === 8) {
        result += " ";
      }
    }
    return result;
  }
}

export const mockData = new RowDataFactory().createRowData();

export const cols = [
  { field: "address", cellDataType: "text", menuTabs: ["generalMenuTab"], editable: true },
  { field: "continent", cellDataType: "text", editable: true },
  { field: "country", cellDataType: "text", editable: true },
  { field: "dob", cellDataType: "date", editable: true },
  { field: "landline", cellDataType: "text", editable: true },
  { field: "language", cellDataType: "text", editable: true },
  { field: "mobile", cellDataType: "text", editable: true },
  { field: "name", cellDataType: "text", editable: true },
  { field: "proficiency", cellDataType: "number", editable: true },
  { field: "skills", cellDataType: "object", editable: true },
  { field: "years", cellDataType: "number", editable: true },
];

export const getRowData = () => {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      resolve(mockData);
    }, 300);
  });
};

export const getColmDefs = () => {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      const rst = [
        { field: "address", cellDataType: "text", menuTabs: ["generalMenuTab"] },
        { field: "continent", cellDataType: "text" },
        { field: "country", cellDataType: "text" },
        { field: "dob", cellDataType: "date" },
        { field: "landline", cellDataType: "text" },
        { field: "language", cellDataType: "text" },
        { field: "mobile", cellDataType: "text" },
        { field: "name", cellDataType: "text" },
        { field: "proficiency", cellDataType: "number" },
        { field: "skills", cellDataType: "object" },
        { field: "years", cellDataType: "number" },
      ];

      resolve(rst);
    }, 300);
  });
};
