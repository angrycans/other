import { useAsyncEffect, useMount } from "ahooks";

import { useStore } from "./store";
import * as API from "./api";
import { ModifyTableType, TableField, TableItem } from "./types";
import * as Tools from "./tools";
import { useCallback, useEffect, useState } from "react";
import moment from "moment";

import AgHeaderAddfield from "./components/ag_header_addfield";
import { Button, message, Popconfirm } from "antd";

export const useDicData = (table: TableItem) => {
  const { updateState } = useStore();

  useAsyncEffect(async () => {
    console.log("useDicData init", table);
    for (const item of table.fields) {
      if (item.enumeration) {
        const ret = await API.getDicData(item.enumeration);
        console.log("useDicData setDicData1", item, ret);
        if (ret.code && ret.datas) {
          console.log("useDicData setDicData2", ret);
          updateState((draft) => {
            draft.app.enums[item.enumeration] = ret.datas.dic.items;
            console.log("useDicData setDicData", ret.datas);
          });
        }
      }
    }
  }, [table]);
};

export const useTableHeader = (table: TableItem) => {
  const { state } = useStore();

  const [colmumsDef, setColmumsDef] = useState();

  function valueParser(params: any) {
    console.log("valueParser", params);
    switch (params.colDef.cellEditor) {
      case "agDateStringCellEditor": {
        // console.log("moment isvalid", moment(params.newValue).isValid);
        const ret = moment(params.newValue).toDate();
        return ret;
        break;
      }
      // case "agRichSelectCellEditor": {
      //   console.log("valueParser agRichSelectCellEditor not valueParser", params);
      //   return params.data[params.colDef.field];
      //   break;
      // }
      default: {
        return params.newValue;
      }
    }
  }

  const valueGetter = (params: any) => {
    //console.log("valueGetter", params);
    switch (params.colDef.cellEditor) {
      case "agDateStringCellEditor": {
        const ret = moment(params.data[params.colDef.field]).format("YYYY-MM-DD");
        // console.log("valueGetter", params.colDef.cellDataType, params, ret);
        return ret;
        break;
      }
      case "agRichSelectCellEditor": {
        console.log("valueGetter", params, params.data[params.colDef.field], table);

        return params.data[params.colDef.field];

        break;
      }
      default: {
        return params.data[params.colDef.field];
      }
    }
  };

  const cellEditorParams = (params: TableField) => {
    //console.log("getCellEditorParams", params);

    switch (params.type) {
      case "Enum": {
        //return setDicData(params.enumeration);
        return {
          values: () => {
            console.log(
              "cellEditorParams ",
              state,
              state.app.enums[params.enumeration],
              params.enumeration
            );
            if (state.app.enums[params.enumeration]) {
              //return (state.app.enums[params.enumeration] as any).map((item: any) => item.content);
              return (state.app.enums[params.enumeration] as any).map((item: any) => item.code);
            } else {
              return [];
            }
          },
        };
        break;
      }

      default: {
        return {};
      }
    }
  };
  function valueFormatter(params: any) {
    switch (params.colDef.cellEditor) {
      case "agRichSelectCellEditor": {
        //return params.data[params.colDef.field];
        console.log("valueFormatter agRichSelectCellEditor ", params, table, state.app.enums);

        const key = table.fields.find((item) => item.name == params.colDef.field);
        if (key && !state.app.enums[key?.enumeration]) return "";
        const ret =
          key &&
          ((state.app.enums[key?.enumeration] as any).find((item: any) => {
            // console.log("find ", item);
            return item.code == params.value;
          }) as any);
        console.log("valueFormatter agRichSelectCellEditor ", params.value, ret);

        return ret ? ret.content : "";
        break;
      }
      default: {
        return params.value;
      }
    }
  }

  useEffect(() => {
    console.log("getTableHeader", table);
    let colmumsDef1 = table.fields.map((item) => {
      const editor = Tools.toAgGridEditorType(item.type);
      return {
        field: item.name,
        headerName: item.caption,
        menuTabs: ["generalMenuTab"],
        editable: item.isSystem ? false : true,
        cellDataType: editor.type,
        cellEditor: editor.editor,
        cellEditorParams: cellEditorParams(item),
        valueParser,
        valueGetter,
        valueFormatter,
        cellStyle: function (params: any) {
          return {
            textAlign: "left",
            // "border-top": "1px solid #e0e0e0",
            borderRight: "1px solid #e0e0e0",
            //"border-left": "1px solid #e0e0e0",
            borderBottom: "1px solid#e0e0e0",
          };
        },
      };
    });
    let colmumsDef_checkbox = [];
    colmumsDef_checkbox.push({
      //field: "__id",
      //headerName: "#",
      editable: false,
      width: 50, // 设置宽度
      sortable: false, // 禁止排序
      filter: false, // 禁止过滤
      pinned: "left", // 如果需要，可以将列固定在左侧
      headerCheckboxSelection: true,
      headerCheckboxSelectionFilteredOnly: true,
      checkboxSelection: true,
      menuTabs: [],
      cellStyle: function (params: any) {
        return {
          textAlign: "left",
          borderRight: "1px solid #e0e0e0",
          borderBottom: "1px solid#e0e0e0",
        };
      },
    });
    let colmumsDef_add = [];
    colmumsDef_add.push({
      //field: "__id",
      headerComponent: AgHeaderAddfield,
      editable: false,
      width: 200, // 设置宽度
      sortable: false, // 禁止排序
      filter: false, // 禁止过滤
      // pinned: "right", // 如果需要，可以将列固定在左侧
      menuTabs: [],
      suppressMenu: true,
    });

    const _colmumsDef = colmumsDef_checkbox
      .concat(colmumsDef1 as any)
      .concat(colmumsDef_add as any);
    console.log("_colmumsDef", _colmumsDef);

    setColmumsDef(_colmumsDef as any);
  }, [table, state.app.enums]);

  return colmumsDef;
};

export const useUpdateTable = () => {
  const { updateState } = useStore();

  const updateTable = useCallback(async (table_name: string) => {
    console.log("useUpdateTable");
    const ret = await API.getFieldsByTable(table_name);
    console.log("useUpdateTable", ret);
    updateState((draft) => {
      let idx = draft.app.tables.findIndex((item) => item.name == table_name);
      draft.app.tables[idx].fields = ret.datas;
      if (draft.app.openTables) {
        idx = draft.app.openTables.findIndex((item) => item.name == table_name);
        draft.app.openTables[idx].fields = ret.datas;
      }
    });
  }, []);

  return { updateTable };
};

export const useAddTable = () => {
  const { updateState } = useStore();

  const addTable = useCallback(async (tabitem: TableItem) => {
    console.log("useUpdateTable");
    const ret = await API.getFieldsByTable(tabitem.name);
    console.log("useUpdateTable", ret);
    updateState((draft) => {
      let idx = draft.app.tables.findIndex((item) => item.name == tabitem.name);
      draft.app.tables[idx].fields = ret.datas;
      if (draft.app.openTables) {
        idx = draft.app.openTables.findIndex((item) => item.name == tabitem.name);
        draft.app.openTables[idx].fields = ret.datas;
      }
    });
  }, []);

  return { addTable };
};

export const useInitTables = () => {
  const { updateState } = useStore();

  const initTables = async (defaultOpenTableKey?: string, tableItem?: TableItem) => {
    console.log("useInitTables");
    let ret1: any;
    if (!tableItem) {
      ret1 = await API.getEntries();
    }

    const ret2 = await API.getALlTableOptionType("Query");
    const ret3 = await API.getALlTableOptionType("Mutation");
    updateState((draft) => {
      console.log(`getALlTableOptionType("Query")`, ret2);
      console.log(`getALlTableOptionType("Mutation")`, ret3);

      if (tableItem) {
        draft.app.tables.push(tableItem);
      } else {
        draft.app.tables = ret1.datas;
      }

      draft.app.tablesOptionType = { Query: ret2.data.__type, Mutation: ret3.data.__type };

      if (defaultOpenTableKey) {
        draft.app.openTablesActiveKey = defaultOpenTableKey;
      }
    });
  };

  return { initTables };
};

export const useAddOpenTables = () => {
  const { state, updateState } = useStore();

  useEffect(() => {
    console.log("useAddOpenTables useEffect", state.app.openTablesActiveKey);
    if (state.app.openTablesActiveKey) {
      const existingItemIndex = state.app.openTables
        ? state.app.openTables.findIndex((item) => item.name === state.app.openTablesActiveKey)
        : -1;
      //console.log("existingItemIndex", existingItemIndex);
      if (existingItemIndex == -1) {
        if (state.app.tables) {
          const addItem = state.app.tables.find(
            (item) => item.name === state.app.openTablesActiveKey
          );
          if (addItem) {
            updateState((draft) => {
              if (!draft.app.openTables) {
                draft.app.openTables = [];
              }

              draft.app.openTables?.push(addItem);
            });
          }

          //draft.app.openTablesActiveKey = pitem.name;
        }
      }
    }
  }, [state.app.openTablesActiveKey]);
};

export const useModifyTable = () => {
  // const { state, updateState } = useStore();
  const { initTables } = useInitTables();

  const modifyTable = async (json: any) => {
    console.log("useModifyTable modifyTable", json);

    let tjson: ModifyTableType = {} as ModifyTableType;
    tjson.caption = json.table_name;
    tjson.itemOrder = json.field_items.map((item: any) => item.item_name);
    tjson.fields = json.field_items.map((item: any) => {
      let ret: any = {
        name: item.item_name,
        caption: item.item_name,
        type: item.item_type,
      };
      item.item_default ? (ret["defaultValue"] = item.item_default) : null;

      item.item_select_dic ? (ret["enumeration"] = item.item_select_dic) : null;

      return ret;
    });

    console.log("tjson", tjson);

    const rst = await API.modifyTable(tjson);
    console.log("modifyTable", rst);
    if (rst.code == 1) {
      initTables(rst.datas.table.name, rst.datas.table);
    }
  };

  return { modifyTable };
};

export const useModifyField = () => {
  const { state, updateState } = useStore();
  const { updateTable } = useUpdateTable();

  const modifyField = async (json: any) => {
    console.log("useModifyTable modifyTable", json);

    let tjson: ModifyTableType = {} as ModifyTableType;
    if (state.app.openTablesActiveKey) {
      tjson.name = state.app.openTablesActiveKey;
      let ret: any = {
        name: json.item_name,
        caption: json.item_name,
        type: json.item_type,
      };
      json.item_default ? (ret["defaultValue"] = json.item_default) : null;

      // json.item_select_dic
      //   ? (ret["enumeration"] = `${tjson.name.substring(1, tjson.name.indexOf("_"))}.${
      //       json.item_select_dic
      //     }`)
      //   : null;

      json.item_select_dic ? (ret["enumeration"] = `${json.item_select_dic}`) : null;

      if (!tjson.fields) tjson.fields = [];
      tjson.fields.push(ret);

      console.log("tjson", tjson);

      const rst = await API.modifyTable(tjson);
      console.log("modifyField", rst);
      if (rst.code == 1) {
        updateTable(state.app.openTablesActiveKey);
      }
    }
  };

  return { modifyField };
};

export const useDeleteTable = () => {
  const { state, updateState } = useStore();

  const deleteTable = async (tablename: any) => {
    console.log("useDeleteTable delteTable", tablename);
    const ret = await API.deleteTable(tablename);

    console.log("useDeleteTable delteTable ret", ret);
    if (ret.code == 1) {
      updateState((draft) => {
        let idx = 0;
        if (draft.app.openTables) {
          for (let i = draft.app.openTables.length - 1; i >= 0; i--) {
            if (draft.app.openTables[i].name === tablename) {
              idx = i;
              draft.app.openTables.splice(i, 1); // Remove the item
            }
          }
          for (let i = draft.app.tables.length - 1; i >= 0; i--) {
            if (draft.app.tables[i].name === tablename) {
              draft.app.tables.splice(i, 1); // Remove the item
            }
          }

          if (draft.app.openTables.length > 0) {
            if (idx - 1 >= 0) {
              draft.app.openTablesActiveKey = draft.app.openTables[idx - 1].name;
            } else {
              draft.app.openTablesActiveKey = draft.app.openTables[idx].name;
            }
          } else {
            draft.app.openTablesActiveKey = "";
          }
        }

        message.success("表删除成功.");
      });
    }
  };

  return { deleteTable };
};
