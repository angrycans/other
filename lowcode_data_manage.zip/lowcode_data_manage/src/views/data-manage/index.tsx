import React, { useEffect, useState, useRef } from "react";
import { Tabs } from "antd";
import type { TabsProps } from "antd";
import {
  MenuFoldOutlined,
  MenuUnfoldOutlined,
  UploadOutlined,
  UserOutlined,
  VideoCameraOutlined,
  DownOutlined,
  SmileOutlined,
  PlusOutlined,
  CheckCircleFilled,
} from "@ant-design/icons";
import type { DragEndEvent } from "@dnd-kit/core";
import { DndContext, PointerSensor, useSensor } from "@dnd-kit/core";
import {
  arrayMove,
  horizontalListSortingStrategy,
  SortableContext,
  useSortable,
} from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";

import { Layout, Menu, Button, theme, Dropdown, Space } from "antd";
const { Header, Sider, Content } = Layout;

import "./index.css";
import Grid from "./components/grid";
import { StoreProvider, useStore } from "./store";

import { useAsyncEffect, useMount } from "ahooks";

import * as API from "./api";

import TablesMenu from "./components/tables_menu";
import TabSubMenu from "./components/tab_submenu";
import CreateTableModal from "./components/create_table_modal";
import Msg from "../../utils/mitt";
import { TableItem } from "./types";
import { useInitTables } from "./hooks";
import CreateFieldModal from "./components/create_field_moda";

interface DraggableTabPaneProps extends React.HTMLAttributes<HTMLDivElement> {
  "data-node-key": string;
}

const DraggableTabNode = ({ className, ...props }: DraggableTabPaneProps) => {
  const { attributes, listeners, setNodeRef, transform, transition } = useSortable({
    id: props["data-node-key"],
  });

  const style: React.CSSProperties = {
    ...props.style,
    transform: CSS.Transform.toString(transform && { ...transform, scaleX: 1 }),
    transition,
    cursor: "move",
  };

  return React.cloneElement(props.children as React.ReactElement, {
    ref: setNodeRef,
    style,
    ...attributes,
    ...listeners,
  });
};

const DataManage: React.FC = () => {
  const { state, updateState } = useStore();

  const [collapsed, setCollapsed] = useState(false);
  const [tabitems, setItems] = useState([]);
  const { initTables } = useInitTables();

  const onTabChange = (key: string) => {
    updateState((draft) => {
      draft.app.openTablesActiveKey = key;
    });
  };

  useMount(() => {
    console.log("data-manage useMount");
    initTables();
  });

  useEffect(() => {
    console.log("data-manage willmount state.app.openTables", state.app.openTables);

    const _tabitems = state.app.openTables?.map((item) => {
      return {
        key: item.name,
        closable: false,
        label: (
          <>
            <Space>{item.caption}</Space>
            <TabSubMenu table_name={item.name} />
            {/* {item.name == state.app.openTablesActiveKey ? (
              <TabSubMenu table_name={item.name} />
            ) : null} */}
          </>
        ),
        //children: item.caption,
        children: <Grid table={item} />,
      };
    });
    setItems(_tabitems as any);
  }, [state.app.openTables]);

  const addTab = () => {
    updateState((draft) => {
      draft.app.createTableModal.open = true;
    });
  };

  const sensor = useSensor(PointerSensor, { activationConstraint: { distance: 10 } });

  const onDragEnd = ({ active, over }: DragEndEvent) => {
    if (active.id !== over?.id) {
      setItems((prev) => {
        const activeIndex = prev.findIndex((i) => (i as any).key === active.id);
        const overIndex = prev.findIndex((i) => (i as any).key === over?.id);
        return arrayMove(prev, activeIndex, overIndex);
      });
    }
  };

  const renderTabBar: TabsProps["renderTabBar"] = (tabBarProps, DefaultTabBar) => (
    <DndContext sensors={[sensor]} onDragEnd={onDragEnd}>
      <SortableContext items={tabitems.map((i) => (i as any).key)}>
        <div style={{ display: "flex" }}>
          <DefaultTabBar {...tabBarProps}>
            {(node) => (
              <DraggableTabNode {...node.props} key={node.key}>
                {node}
              </DraggableTabNode>
            )}
          </DefaultTabBar>
        </div>
      </SortableContext>
    </DndContext>
  );

  return (
    <Layout style={{ height: "100%" }}>
      <Sider trigger={null} collapsible collapsed={collapsed} collapsedWidth="0" width="180px">
        <TablesMenu />
      </Sider>
      <Layout
        style={{
          padding: 10,
          minHeight: "280px",
          height: "100%",
        }}
      >
        {tabitems && (
          <Tabs
            // style={{ width: "100%", height: "100%" }}
            className="antd-parent"
            //defaultActiveKey={state.app.openTablesActiveKey}
            activeKey={state.app.openTablesActiveKey}
            type="card"
            items={tabitems}
            renderTabBar={renderTabBar}
            onChange={onTabChange}
            //onEdit={onEdit}
            tabBarExtraContent={{
              left: (
                <Button
                  type="text"
                  icon={collapsed ? <MenuUnfoldOutlined /> : <MenuFoldOutlined />}
                  onClick={() => setCollapsed(!collapsed)}
                />
              ),
              right: <Button type="text" icon={<PlusOutlined />} onClick={() => addTab()} />,
            }}
          />
        )}
      </Layout>
      <CreateTableModal />
      <CreateFieldModal />
    </Layout>
  );
};

const ReduxProviderContext: React.FC = () => {
  return (
    <StoreProvider>
      <DataManage />
    </StoreProvider>
  );
};

export default ReduxProviderContext;
