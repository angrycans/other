import React, { useState } from "react";
import { Breadcrumb, MenuProps } from "antd";
import { Link, useLocation } from "react-router-dom";
type MenuItem = Required<MenuProps>["items"][number];

import { breadcrumbNameMap } from "../../../App";

const Breadcrumbs: React.FC = () => {
  const location = useLocation();

  // 生成面包屑项
  const pathSnippets = location.pathname.split("/").filter((i) => i);
  const extraBreadcrumbItems = pathSnippets.map((_, index) => {
    const url = `/${pathSnippets.slice(0, index + 1).join("/")}`;
    const breadcrumbName = breadcrumbNameMap[url] || url;
    return (
      <Breadcrumb.Item key={url}>
        <Link to={url}>{breadcrumbName}</Link>
      </Breadcrumb.Item>
    );
  });

  // 面包屑首页项
  const breadcrumbItems = [
    <Breadcrumb.Item key="home">
      <Link to="/">Home</Link>
    </Breadcrumb.Item>,
  ].concat(extraBreadcrumbItems);

  return <Breadcrumb>{breadcrumbItems}</Breadcrumb>;
};

export default Breadcrumbs;
