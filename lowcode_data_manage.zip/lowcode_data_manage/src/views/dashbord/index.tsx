import React, { useState, useEffect } from "react";

import { Layout, theme, Breadcrumb, Menu } from "antd";
import { Outlet, Link, useParams } from "react-router-dom";

const { Header, Content, Sider } = Layout;
import type { MenuProps } from "antd";
import {
  DesktopOutlined,
  FileOutlined,
  PieChartOutlined,
  TeamOutlined,
  UserOutlined,
} from "@ant-design/icons";
type MenuItem = Required<MenuProps>["items"][number];

import AppMenu from "./appmenu";
import AppConfig from "../../AppConfig";
//import Breadcrumbs from "./breadcrumb";

function getItem(
  label: React.ReactNode,
  key: React.Key,
  icon?: React.ReactNode,
  children?: MenuItem[]
): MenuItem {
  return {
    key,
    icon,
    children,
    label,
  } as MenuItem;
}

const DashBoard: React.FC = () => {
  const [collapsed, setCollapsed] = useState(false);

  const { appID } = useParams();
  const [items, setItems] = useState<MenuItem[]>();

  const {
    token: { colorBgContainer, borderRadiusLG },
  } = theme.useToken();

  AppConfig.setAppID(appID as string);

  useEffect(() => {
    const _items: MenuItem[] = !appID
      ? []
      : [
          getItem("数据管理", "sub0", <FileOutlined />, [
            getItem(
              <Link to={`/data-manage/${appID}/internal`}>内部数据</Link>,
              "sub1",
              <PieChartOutlined />
            ),
            getItem(
              <Link to={`/data-manage/${appID}/external`}>外部数据</Link>,
              "sub2",
              <DesktopOutlined />,
              [
                getItem(
                  <Link to={`/data-manage/${appID}/external/source`}>数据源管理</Link>,
                  "sub2-1"
                ),
              ]
            ),
            getItem("数据模型", "sub3", <FileOutlined />),

            getItem("大数据", "sub4", <UserOutlined />, [
              getItem(<Link to="/about">数据源管理</Link>, "sub4-1"),
              getItem(<Link to="/about">数据资产管理</Link>, "sub4-2"),
              getItem(<Link to="/about">数据服务</Link>, "sub4-3"),
            ]),
          ]),

          getItem("API管理", "sub5", <FileOutlined />),
        ];

    setItems(_items);
    return () => {};
  }, []);

  return (
    <Layout hasSider>
      <Sider
        style={{
          minHeight: "100vh",
          overflow: "auto",
          height: "100vh",
          position: "fixed",
          left: 0,
          top: 0,
          bottom: 0,
        }}
        collapsedWidth={60}
        collapsible
        collapsed={collapsed}
        onCollapse={(value) => {
          !value ? 200 : 50;
          setCollapsed(value);
        }}
      >
        {items && <AppMenu MenuItems={items} />}
      </Sider>
      <Layout
        style={{
          padding: 0,
          height: "100%",
          marginTop: 0,
          marginLeft: !collapsed ? 200 : 50,
          transition: "all 0.2s",
        }}
      >
        <Content
          style={{ margin: "16px 16px 0", minWidth: "900px", height: "100%", overflow: "initial" }}
        >
          {/* <Breadcrumbs /> */}
          <div
            style={{
              //height: "calc(100vh - 40px)",
              height: "calc(100vh)",
              padding: "16px 5px",
              textAlign: "center",
              background: colorBgContainer,
              borderRadius: borderRadiusLG,
            }}
          >
            <Outlet />
          </div>
        </Content>
      </Layout>
    </Layout>
  );
};

export default DashBoard;
