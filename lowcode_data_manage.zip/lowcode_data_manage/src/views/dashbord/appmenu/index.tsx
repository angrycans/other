import React, { useState, useEffect } from "react";
import {
  DesktopOutlined,
  FileOutlined,
  PieChartOutlined,
  TeamOutlined,
  UserOutlined,
} from "@ant-design/icons";
import type { MenuProps } from "antd";
import { Button, Menu } from "antd";

import { Link, useParams } from "react-router-dom";

type MenuItem = Required<MenuProps>["items"][number];

interface propsMenuItems {
  MenuItems: MenuItem[];
}

const AppMenu: React.FC<propsMenuItems> = (menuItem) => {
  return (
    <Menu
      theme="dark"
      defaultOpenKeys={["sub0"]}
      defaultSelectedKeys={["sub1"]}
      mode="inline"
      items={menuItem.MenuItems}
    />
  );
};

export default AppMenu;
